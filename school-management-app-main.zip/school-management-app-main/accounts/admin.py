from django.contrib import admin
from .models import CustomBaseUser

admin.site.register(CustomBaseUser)