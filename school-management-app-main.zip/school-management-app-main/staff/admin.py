from django.contrib import admin

from .models import Staff

# Register your models here.

admin.site.register(Staff)